import logging

logger = logging.getLogger("config")

# Read properties from file
with open('config/properties.conf') as f:
    properties = {}
    for line in f:
        logger.debug(line)
        key, val = line.split("=")
        properties[key] = val.strip()  # Remove trailing newline
