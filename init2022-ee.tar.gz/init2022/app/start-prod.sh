# Start application in production (live) mode
export FLASK_APP=app.py
export FLASK_DEBUG=0
flask run