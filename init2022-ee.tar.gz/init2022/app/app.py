import os

from flask import Flask, render_template
from werkzeug.exceptions import abort
import logging

app = Flask(__name__)

logging.basicConfig(level=logging.INFO, filename='logs/app.log', format='[%(asctime)s] %(levelname)s %(filename)s: %(message)s')
logger = logging.getLogger("app")
print(" * Application log location: logs/app.log")

# get rid of some logs in console
w_logger = logging.getLogger('werkzeug')
for handler in w_logger.handlers:
    w_logger.removeHandler(handler)

logger.info("Loading configuration")
from config import properties
app.config['SECRET_KEY'] = properties["flask_key"]
FLASK_DEBUG = os.getenv('FLASK_DEBUG')

from functions import get_metering_point_data, get_db_connection


@app.route('/')
def index():
    conn = get_db_connection()
    data = []

    logger.info("Fetching list of metering points from database")
    metering_points = conn.execute('SELECT * from metering_point').fetchall()
    for metering_point in metering_points:
        logger.info(dict(metering_point))
        data.append(get_metering_point_data(metering_point["metering_point_id"]))
    conn.close()
    return render_template('index.html', metering_points=data, FLASK_DEBUG=FLASK_DEBUG)

@app.route('/<int:metering_point_id>')
def metering_point(metering_point_id):
    metering_point = get_metering_point_data(metering_point_id)
    if metering_point is None:
        abort(404)
    return render_template('metering_point.html', metering_point=metering_point, FLASK_DEBUG=FLASK_DEBUG)