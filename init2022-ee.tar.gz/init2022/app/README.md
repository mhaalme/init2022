## DEV install
```
# create python virtual environment
python3 -m venv venv
source venv/bin/activate

# install requirements
pip install -r requirements.txt

# run application
./start-dev.sh
```

Open app at http://127.0.0.1:5000/

## Environments

The application can be run in two modes:
- dev - for testing and development only with test data
- prod - for use in production to manage real user data

