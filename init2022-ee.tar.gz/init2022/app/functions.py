import logging
import sqlite3

from config import properties

logger = logging.getLogger("functions")

def get_db_connection():
    conn = sqlite3.connect(properties["database"])
    conn.row_factory = sqlite3.Row
    return conn


def get_metering_point_data(metering_point_id):
    conn = get_db_connection()
    query = 'SELECT * from metering_point where metering_point_id = {metering_point_id}'.format(
        metering_point_id=metering_point_id)

    logger.info("Running SQL query: {}".format(query))
    metering_point = conn.execute(query).fetchone()
    if metering_point is None:
        logger.info("No rows found")
        return None
    else:
        logger.info("Found metering point {}".format(dict(metering_point)))

    consumption = get_consumption(metering_point_id)
    data = {
        "metering_point_id": metering_point["metering_point_id"],
        "address": metering_point["address"],
        "name": metering_point["name"],
        "consumption": consumption
    }
    return data


def get_consumption(metering_point_id):
    conn = get_db_connection()
    query = 'SELECT * FROM consumption where metering_point_id = {metering_point_id}'.format(
        metering_point_id=metering_point_id)

    logger.info("Running SQL query: {}".format(query))
    consumption = conn.execute(query).fetchall()
    logger.info("{} rows found".format(len(consumption)))

    conn.close()
    return consumption
