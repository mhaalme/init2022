DROP TABLE IF EXISTS metering_point;
DROP TABLE IF EXISTS consumption;

CREATE TABLE metering_point (
    metering_point_id INTEGER PRIMARY KEY AUTOINCREMENT,
    address TEXT NOT NULL,
    name TEXT NOT NULL
);

CREATE TABLE consumption (
   id INTEGER PRIMARY KEY AUTOINCREMENT,
   metering_point_id INTEGER,
   period TEXT NOT NULL,
   amount REAL NOT NULL,
   FOREIGN KEY (metering_point_id)
      REFERENCES metering_point (metering_point_id)
         ON DELETE CASCADE
         ON UPDATE NO ACTION
);
