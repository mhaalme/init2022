# Start application in DEV mode
export FLASK_APP=app.py
export FLASK_DEBUG=1
flask run